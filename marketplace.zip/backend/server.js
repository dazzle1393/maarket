const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'marketplace'
});

db.connect(err => {
    if (err) throw err;
    console.log('Подключено к MySQL');
});

app.post('/register', (req, res) => {
    const { username, password, role } = req.body;
    const sql = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
    db.query(sql, [username, password, role], (err, result) => {
        if (err) throw err;
        res.send({ message: 'Пользователь зарегистрирован!' });
    });
});

app.listen(3000, () => console.log('Сервер запущен на порту 3000'));
